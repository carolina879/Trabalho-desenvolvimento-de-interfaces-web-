document.addEventListener("DOMContentLoaded", () => {
    const params = new URLSearchParams(window.location.search);
    const recipeId = params.get("data-id");

    const recipes = {
        1: {
            title: "Risotto",
            image: "images/0bea444f-d141-4101-99dd-eb497aa8b588-unnamed.png",
            ingredients: ["Arroz", "Queijo", "Caldo de legumes"],
            preparation: "1. Aqueça o caldo de legumes e mantenha-o quente. \n2. Em uma panela, refogue cebola e alho em azeite. \n3. Adicione o arroz e mexa por 2 minutos. \n4. Acrescente o vinho branco e mexa até evaporar. \n5. Adicione o caldo aos poucos, mexendo sempre, até o arroz ficar al dente. \n6. Finalize com queijo ralado e manteiga, misturando bem."
        },
        2: {
            title: "Macarrão a Carbonara",
            image: "images/66abdc6bb23453a93e91b5edd6dc722a.png",
            ingredients: ["Macarrão", "Bacon", "Ovos", "Queijo"],
            preparation: "1. Cozinhe o macarrão em água salgada até ficar al dente. \n2. Enquanto isso, frite o bacon até dourar. \n3. Em uma tigela, misture os ovos com queijo ralado e pimenta. \n4. Escorra o macarrão e misture imediatamente com o bacon e a mistura de ovos, mexendo rapidamente para formar um molho cremoso. \n5. Sirva com mais queijo ralado por cima."
        },
        3: {
            title: "Salada Caesar",
            image: "images/kotosalata-eukoli-kalokairini-salates-salata-eisaimonadikigr.png",
            ingredients: ["Alface", "Frango", "Croutons"],
            preparation: "1. Lave e seque as folhas de alface. \n2. Grelhe o frango temperado com sal e pimenta e corte em tiras. \n3. Prepare o molho misturando maionese, suco de limão, alho, queijo ralado e azeite. \n4. Monte a salada com alface, frango, croutons e regue com o molho. \n5. Finalize com queijo ralado por cima."
        },
        4: {
            title: "Sopa de Abóbora",
            image: "images/weight-watchers-absolutely-most-delicious-pumpkin-soup.png",
            ingredients: ["Abóbora", "Creme de leite", "Temperos"],
            preparation: "1. Descasque e corte a abóbora em pedaços. \n2. Cozinhe a abóbora em água com sal até ficar macia. \n3. Bata a abóbora no liquidificador com um pouco da água do cozimento. \n4. Volte à panela, adicione creme de leite e tempere com sal, pimenta e noz-moscada. \n5. Cozinhe por mais alguns minutos e sirva quente."
        },
        5: {
            title: "Pudim de Leite",
            image: "images/pudim.png",
            ingredients: [
                "1 lata de leite condensado",
                "1 lata de leite (mesma medida do leite condensado)",
                "3 ovos",
                "1 xícara de açúcar (para a calda)",
                "1/2 xícara de água (para a calda)"
            ],
            preparation: "1. Derreta o açúcar em fogo baixo até caramelizar e adicione a água, formando a calda. Despeje em uma forma de pudim. \n2. Bata os ovos, leite condensado e leite no liquidificador até ficar homogêneo. \n3. Despeje a mistura na forma e asse em banho-maria a 180°C por cerca de 1 hora. \n4. Deixe esfriar, leve à geladeira por 4 horas e desenforme."
        },
        6: {
            title: "Brigadeiro",
            image: "images/ubn001-20e-instagram-ubn-dez-ju-site-5-copy-4-800.png",
            ingredients: [
                "1 lata de leite condensado",
                "2 colheres de sopa de chocolate em pó",
                "1 colher de sopa de manteiga",
                "Chocolate granulado para enrolar"
            ],
            preparation: "1. Em uma panela, misture o leite condensado, chocolate em pó e manteiga. \n2. Cozinhe em fogo médio, mexendo sempre, até desgrudar do fundo da panela. \n3. Deixe esfriar, enrole em bolinhas e passe no chocolate granulado."
        },
        7: {
            title: "Mousse de Maracujá",
            image: "images/mousse-maracuja.png",
            ingredients: [
                "1 lata de leite condensado",
                "1 lata de creme de leite",
                "1 xícara de suco de maracujá concentrado"
            ],
            preparation: "1. Bata todos os ingredientes no liquidificador até obter uma mistura homogênea. \n2. Despeje em taças e leve à geladeira por pelo menos 4 horas antes de servir."
        },
        8: {
            title: "Rocambole",
            image: "images/2222c3f9c48915b892432b8c10e92882.png",
            ingredients: [
                "4 ovos",
                "4 colheres de sopa de açúcar",
                "4 colheres de sopa de farinha de trigo",
                "1 colher de chá de fermento em pó",
                "Recheio a gosto (doce de leite, brigadeiro, creme de chocolate)"
            ],
            preparation: "1. Bata os ovos e o açúcar até dobrar de volume. \n2. Adicione a farinha e o fermento peneirados, misturando delicadamente. \n3. Asse em forma forrada com papel manteiga a 180°C por 10 minutos. \n4. Desenforme, espalhe o recheio e enrole cuidadosamente. \n5. Decore a gosto e sirva."
        }
    };

    const recipe = recipes[recipeId];
    if (recipe) {
        document.getElementById("recipe-title").textContent = recipe.title;
        document.getElementById("recipe-image").src = recipe.image;
        const ingredientsList = document.getElementById("recipe-ingredients");
        recipe.ingredients.forEach(ingredient => {
            const li = document.createElement("li");
            li.textContent = ingredient;
            li.classList.add("list-group-item");
            ingredientsList.appendChild(li);
        });
        document.getElementById("recipe-preparation").textContent = recipe.preparation;
    } else {
        document.body.innerHTML = "<h1 class='text-center'>Receita não encontrada</h1>";
    }
});
