
if (typeof Chart === 'undefined') {
    console.error('Chart.js não foi carregado');
}

document.addEventListener("DOMContentLoaded", carregarEstatisticas);

window.addEventListener('receitaAdicionada', () => {
    carregarEstatisticas();
});

async function carregarEstatisticas() {
    console.log('Página carregada, iniciando...');
    
    let receitas = [];
    
    try {
       
        if (typeof fetchReceitas === 'function') {
            console.log('Tentando buscar todas as receitas da API...');
            receitas = await fetchReceitas();
            console.log('Receitas encontradas na API:', receitas);
        }
        
        if (!receitas || receitas.length === 0) {
            console.log('API não disponível, usando dados de exemplo...');
            receitas = obterReceitasExemplo();
        }

   
        const dadosProcessados = processarDados(receitas);
        console.log('Dados processados:', dadosProcessados);
      
        criarGraficos(dadosProcessados, receitas);
        
    } catch (error) {
        console.error("Erro ao carregar dados:", error);
      
        const receitasExemplo = obterReceitasExemplo();
        const dadosProcessados = processarDados(receitasExemplo);
        criarGraficos(dadosProcessados, receitasExemplo);
    }
}

function obterReceitasExemplo() {
 
    return [
        {
            id: 1,
            title: "Risotto",
            categoria: "Prato Principal",
            ingredients: ["Arroz", "Queijo", "Caldo de legumes", "Cebola", "Alho", "Vinho branco", "Manteiga"]
        },
        {
            id: 2,
            title: "Macarrão a Carbonara",
            categoria: "Prato Principal",
            ingredients: ["Macarrão", "Bacon", "Ovos", "Queijo", "Pimenta"]
        },
        {
            id: 3,
            title: "Salada Caesar",
            categoria: "Saladas",
            ingredients: ["Alface", "Frango", "Croutons", "Maionese", "Limão", "Alho"]
        },
        {
            id: 4,
            title: "Sopa de Abóbora",
            categoria: "Prato Principal",
            ingredients: ["Abóbora", "Cebola", "Alho", "Caldo", "Temperos", "Creme de leite"]
        },
        {
            id: 5,
            title: "Lasanha de Carne",
            categoria: "Prato Principal",
            ingredients: ["Massa de lasanha", "Carne moída", "Molho de tomate", "Queijo", "Cebola", "Alho", "Manjericão"]
        },
        {
            id: 6,
            title: "Brigadeiro",
            categoria: "Sobremesas",
            ingredients: ["Leite condensado", "Chocolate em pó", "Manteiga", "Granulado"]
        },
        {
            id: 7,
            title: "Mousse de Maracujá",
            categoria: "Sobremesas",
            ingredients: ["Maracujá", "Leite condensado", "Creme de leite", "Gelatina"]
        },
        {
            id: 8,
            title: "Tiramisu",
            categoria: "Sobremesas",
            ingredients: ["Biscoito champagne", "Café", "Mascarpone", "Ovos", "Açúcar", "Cacau"]
        },
        {
            id: 9,
            title: "Pudim de Leite",
            categoria: "Sobremesas",
            ingredients: ["Leite condensado", "Leite", "Ovos", "Açúcar"]
        },
        {
            id: 10,
            title: "Salada de Frutas",
            categoria: "Sobremesas",
            ingredients: ["Maçã", "Banana", "Uva", "Laranja", "Suco de laranja", "Açúcar"]
        }
    ];
}

function processarDados(receitas) {
    console.log('Processando dados de', receitas.length, 'receitas');
    
    const categorias = {};
    const temposPreparo = {
        "Até 30 min": 0,
        "30-60 min": 0,
        "1-2 horas": 0,
        "Mais de 2h": 0
    };
    const numeroIngredientes = {};

    receitas.forEach(receita => {
       
        const categoria = receita.categoria || determinarCategoria(receita.title);
        categorias[categoria] = (categorias[categoria] || 0) + 1;

  
        const tempo = estimarTempoPreparo(receita.title);
        if (tempo <= 30) temposPreparo["Até 30 min"]++;
        else if (tempo <= 60) temposPreparo["30-60 min"]++;
        else if (tempo <= 120) temposPreparo["1-2 horas"]++;
        else temposPreparo["Mais de 2h"]++;

        
        const numIngredientes = receita.ingredients ? receita.ingredients.length : 0;
        const faixa = getFaixaIngredientes(numIngredientes);
        numeroIngredientes[faixa] = (numeroIngredientes[faixa] || 0) + 1;
    });

    console.log('Categorias:', categorias);
    console.log('Tempos de preparo:', temposPreparo);
    console.log('Número de ingredientes:', numeroIngredientes);

    return { categorias, temposPreparo, numeroIngredientes };
}

function determinarCategoria(titulo) {
    const titulo_lower = titulo.toLowerCase();
    if (titulo_lower.includes('brigadeiro') || titulo_lower.includes('mousse') || 
        titulo_lower.includes('doce') || titulo_lower.includes('tiramisu') || 
        titulo_lower.includes('pudim') || titulo_lower.includes('frutas')) {
        return 'Sobremesas';
    } else if (titulo_lower.includes('risotto') || titulo_lower.includes('macarrão') || 
               titulo_lower.includes('sopa') || titulo_lower.includes('lasanha')) {
        return 'Prato Principal';
    } else if (titulo_lower.includes('salada')) {
        return 'Saladas';
    }
    return 'Outros';
}

function estimarTempoPreparo(titulo) {
    const titulo_lower = titulo.toLowerCase();
    if (titulo_lower.includes('brigadeiro')) return 20;
    if (titulo_lower.includes('mousse')) return 15;
    if (titulo_lower.includes('salada de frutas')) return 10;
    if (titulo_lower.includes('salada')) return 15;
    if (titulo_lower.includes('risotto')) return 45;
    if (titulo_lower.includes('macarrão')) return 25;
    if (titulo_lower.includes('sopa')) return 60;
    if (titulo_lower.includes('lasanha')) return 90;
    if (titulo_lower.includes('tiramisu')) return 30;
    if (titulo_lower.includes('pudim')) return 120;
    return 30; 
}

function getFaixaIngredientes(num) {
    if (num <= 3) return "1-3 ingredientes";
    if (num <= 6) return "4-6 ingredientes";
    if (num <= 10) return "7-10 ingredientes";
    return "Mais de 10";
}

function criarGraficos(dadosProcessados, receitas) {
    try {
        console.log('Criando gráficos...');
        criarGraficoPizza(dadosProcessados.categorias);
        criarGraficoTempo(dadosProcessados.temposPreparo);
        criarGraficoIngredientes(dadosProcessados.numeroIngredientes);
        criarTabelaResumo(receitas, dadosProcessados);
        console.log('Gráficos criados com sucesso!');
    } catch (error) {
        console.error('Erro ao criar gráficos:', error);
    }
}

function criarGraficoPizza(categorias) {
    const ctx = document.getElementById('categoryChart');
    if (!ctx) {
        console.error('Canvas categoryChart não encontrado');
        return;
    }
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(categorias),
            datasets: [{
                data: Object.values(categorias),
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF',
                    '#FF9F40'
                ],
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

function criarGraficoTempo(temposPreparo) {
    const ctx = document.getElementById('timeChart');
    if (!ctx) {
        console.error('Canvas timeChart não encontrado');
        return;
    }
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(temposPreparo),
            datasets: [{
                label: 'Número de Receitas',
                data: Object.values(temposPreparo),
                backgroundColor: '#36A2EB',
                borderColor: '#2E86AB',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function criarGraficoIngredientes(numeroIngredientes) {
    const ctx = document.getElementById('ingredientsChart');
    if (!ctx) {
        console.error('Canvas ingredientsChart não encontrado');
        return;
    }
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(numeroIngredientes),
            datasets: [{
                label: 'Número de Receitas',
                data: Object.values(numeroIngredientes),
                backgroundColor: '#FFCE56',
                borderColor: '#FFB84D',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function criarTabelaResumo(receitas, dadosProcessados) {
    const totalReceitas = receitas.length;
    const categorias = Object.keys(dadosProcessados.categorias);
    const categoriaPopular = categorias.length > 0 ? categorias.reduce((a, b) => 
        dadosProcessados.categorias[a] > dadosProcessados.categorias[b] ? a : b
    ) : 'N/A';
    
    const html = `
        <div class="row">
            <div class="col-md-3">
                <div class="text-center">
                    <h3 class="text-primary">${totalReceitas}</h3>
                    <p class="mb-0">Total de Receitas</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <h3 class="text-success">${categorias.length}</h3>
                    <p class="mb-0">Categorias</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <h3 class="text-warning">${categoriaPopular}</h3>
                    <p class="mb-0">Categoria Popular</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center">
                    <h3 class="text-info">${dadosProcessados.temposPreparo["Até 30 min"]}</h3>
                    <p class="mb-0">Receitas Rápidas</p>
                </div>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-12">
                <h6>Lista de Receitas:</h6>
                <ul class="list-group">
                    ${receitas.map(receita => `
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><strong>${receita.title}</strong> - ${receita.categoria || determinarCategoria(receita.title)}</span>
                            <span class="badge bg-primary rounded-pill">${receita.ingredients ? receita.ingredients.length : 0} ingredientes</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        </div>
    `;
    
    const summaryElement = document.getElementById('summaryTable');
    if (summaryElement) {
        summaryElement.innerHTML = html;
    } else {
        console.error('Elemento summaryTable não encontrado');
    }
}