
document.addEventListener('DOMContentLoaded', function() {
    carregarReceitasPorTipo('sobremesa', 'receitas-sobremesas');
});