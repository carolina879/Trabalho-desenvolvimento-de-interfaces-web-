const apiUrl = "http://localhost:3000/receitas";

async function fetchReceitas() {
    try {
        const response = await fetch(apiUrl);
        return await response.json();
    } catch (error) {
        console.error("Erro ao buscar receitas:", error);
        return [];
    }
}

async function fetchReceitaById(id) {
    try {
        const response = await fetch(`${apiUrl}/${id}`);
        return await response.json();
    } catch (error) {
        console.error("Erro ao buscar receita:", error);
        return null;
    }
}