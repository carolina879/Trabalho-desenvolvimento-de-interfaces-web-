
let receitas = [];
let editandoId = null;


document.addEventListener('DOMContentLoaded', function() {
    console.log('Página Home carregada');
    inicializarPagina();
});


async function inicializarPagina() {
    await carregarReceitas();
    configurarFormulario();
    exibirReceitas();
}


async function carregarReceitas() {
    try {

        const receitasLocal = localStorage.getItem('receitas');
        if (receitasLocal) {
            receitas = JSON.parse(receitasLocal);
            console.log('Receitas carregadas do localStorage:', receitas);
            return;
        }

        const response = await fetch('http://localhost:3000/receitas');
        if (response.ok) {
            receitas = await response.json();
            console.log('Receitas carregadas do servidor:', receitas);
           
            localStorage.setItem('receitas', JSON.stringify(receitas));
        } else {
            throw new Error('Erro ao carregar do servidor');
        }
    } catch (error) {
        console.log('Usando dados de exemplo:', error.message);
        receitas = [
            {
                id: 1,
                nome: "Mousse de Maracujá",
                imagem: "images/mousse-maracuja.png",
                ingredientes: "Leite condensado, Creme de leite, Suco de maracujá, Gelatina",
                preparo: "Dissolva a gelatina conforme as instruções da embalagem. Bata todos os ingredientes no liquidificador até ficar homogêneo. Leve à geladeira por 4 horas.",
                tipo: "sobremesa"
            },
            {
                id: 2,
                nome: "Risotto de Camarão",
                imagem: "images/0bea444f-d141-4101-99dd-eb497aa8b588-unnamed.png",
                ingredientes: "Arroz arbóreo, Camarão, Cebola, Alho, Vinho branco, Caldo de legumes",
                preparo: "Refogue a cebola e o alho, adicione o arroz e vá acrescentando o caldo aos poucos, mexendo sempre. Adicione os camarões no final.",
                tipo: "prato-principal"
            },
            {
                id: 3,
                nome: "Pudim de Leite Condensado",
                imagem: "images/pudim.png",
                ingredientes: "Leite condensado, Leite, Ovos, Açúcar",
                preparo: "Faça a calda com o açúcar, bata os demais ingredientes no liquidificador, despeje na forma caramelizada e asse em banho-maria por 1 hora.",
                tipo: "sobremesa"
            }
        ];
   
        localStorage.setItem('receitas', JSON.stringify(receitas));
    }
}


function configurarFormulario() {
    const form = document.getElementById('form-receita');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            if (editandoId) {
                await editarReceita();
            } else {
                await cadastrarReceita();
            }
        });
    }
}


async function cadastrarReceita() {
    const nome = document.getElementById('nome').value.trim();
    const imagem = document.getElementById('imagem').value.trim();
    const ingredientes = document.getElementById('ingredientes').value.trim();
    const preparo = document.getElementById('preparo').value.trim();
    const tipo = document.getElementById('tipo').value;

    if (!nome || !ingredientes || !preparo || !tipo) {
        mostrarMensagem('Por favor, preencha todos os campos obrigatórios!', 'danger');
        return;
    }

    const novaReceita = {
        id: Date.now(), 
        nome,
        imagem: imagem || 'https://via.placeholder.com/300x200/cccccc/666666?text=Sem+Imagem',
        ingredientes,
        preparo,
        tipo
    };

    try {
      
        const response = await fetch('http://localhost:3000/receitas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(novaReceita)
        });

        if (response.ok) {
            const receitaSalva = await response.json();
            novaReceita.id = receitaSalva.id; 
            console.log('Receita salva no servidor:', receitaSalva);
        } else {
            console.log('Erro ao salvar no servidor, salvando localmente');
        }
    } catch (error) {
        console.log('Salvando apenas localmente:', error.message);
    }

    receitas.push(novaReceita);
    
    localStorage.setItem('receitas', JSON.stringify(receitas));
   
    document.getElementById('form-receita').reset();
    
    
    mostrarMensagem('Receita cadastrada com sucesso!', 'success');
   
    exibirReceitas();
    
    console.log('Receita adicionada. Total de receitas:', receitas.length);
}


async function editarReceita() {
    const nome = document.getElementById('nome').value.trim();
    const imagem = document.getElementById('imagem').value.trim();
    const ingredientes = document.getElementById('ingredientes').value.trim();
    const preparo = document.getElementById('preparo').value.trim();
    const tipo = document.getElementById('tipo').value;

    if (!nome || !ingredientes || !preparo || !tipo) {
        mostrarMensagem('Por favor, preencha todos os campos obrigatórios!', 'danger');
        return;
    }

    const receitaAtualizada = {
        id: editandoId,
        nome,
        imagem: imagem || 'https://via.placeholder.com/300x200/cccccc/666666?text=Sem+Imagem',
        ingredientes,
        preparo,
        tipo
    };

    try {
       
        const response = await fetch(`http://localhost:3000/receitas/${editandoId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(receitaAtualizada)
        });

        if (response.ok) {
            console.log('Receita atualizada no servidor');
        } else {
            console.log('Erro ao atualizar no servidor, atualizando localmente');
        }
    } catch (error) {
        console.log('Atualizando apenas localmente:', error.message);
    }


    const index = receitas.findIndex(r => r.id === editandoId);
    if (index !== -1) {
        receitas[index] = receitaAtualizada;
    }

    localStorage.setItem('receitas', JSON.stringify(receitas));

    cancelarEdicao();
    
    
    mostrarMensagem('Receita atualizada com sucesso!', 'success');
    
    exibirReceitas();
}


function prepararEdicao(id) {
    const receita = receitas.find(r => r.id === id);
    if (!receita) return;

    editandoId = id;
    
    
    document.getElementById('nome').value = receita.nome;
    document.getElementById('imagem').value = receita.imagem;
    document.getElementById('ingredientes').value = receita.ingredientes;
    document.getElementById('preparo').value = receita.preparo;
    document.getElementById('tipo').value = receita.tipo;
    
    
    document.getElementById('titulo-form').textContent = 'Editar Receita';
    document.getElementById('btn-submit').textContent = 'Atualizar';
    document.getElementById('btn-cancelar').style.display = 'inline-block';
    
    document.getElementById('form-receita').scrollIntoView({ behavior: 'smooth' });
}


function cancelarEdicao() {
    editandoId = null;
    
  
    document.getElementById('form-receita').reset();
    

    document.getElementById('titulo-form').textContent = 'Cadastrar Nova Receita';
    document.getElementById('btn-submit').textContent = 'Cadastrar';
    document.getElementById('btn-cancelar').style.display = 'none';
}

async function excluirReceitaConfirmada(id) {
    if (!confirm('Tem certeza que deseja excluir esta receita?')) {
        return;
    }

    try {
 
        const response = await fetch(`http://localhost:3000/receitas/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            console.log('Receita excluída do servidor');
        } else {
            console.log('Erro ao excluir do servidor, excluindo localmente');
        }
    } catch (error) {
        console.log('Excluindo apenas localmente:', error.message);
    }


    receitas = receitas.filter(r => r.id !== id);

    localStorage.setItem('receitas', JSON.stringify(receitas));
    
   
    if (editandoId === id) {
        cancelarEdicao();
    }
    
   
    mostrarMensagem('Receita excluída com sucesso!', 'success');
    
    
    exibirReceitas();
}
function mostrarMensagem(texto, tipo) {
    const mensagem = document.getElementById('mensagem');
    if (mensagem) {
        mensagem.className = `alert alert-${tipo}`;
        mensagem.textContent = texto;
        mensagem.style.display = 'block';
        
       
        setTimeout(() => {
            mensagem.style.display = 'none';
        }, 3000);
    }
}


function exibirReceitas() {
  
    const container = document.getElementById('receitasCadastradas');
    
    if (!container) return;

    if (receitas.length === 0) {
        container.innerHTML = '<div class="col-12"><p class="text-center text-muted">Nenhuma receita cadastrada ainda.</p></div>';
        return;
    }

    const cardsHTML = receitas.map(receita => `
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card h-100 shadow-sm">
                <img src="${receita.imagem}" class="card-img-top" alt="${receita.nome}" style="height: 200px; object-fit: cover;" onerror="this.src='https://via.placeholder.com/300x200/cccccc/666666?text=Sem+Imagem'">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">${receita.nome}</h5>
                    <p class="card-text flex-grow-1">
                        <strong>Ingredientes:</strong> ${receita.ingredientes}<br>
                        <strong>Preparo:</strong> ${receita.preparo.substring(0, 100)}${receita.preparo.length > 100 ? '...' : ''}
                    </p>
                    <div class="mt-auto">
                        <span class="badge bg-${receita.tipo === 'prato-principal' ? 'primary' : 'warning'} text-${receita.tipo === 'prato-principal' ? 'white' : 'dark'} mb-2">
                            <i class="fas fa-${receita.tipo === 'prato-principal' ? 'utensils' : 'birthday-cake'}"></i>
                            ${receita.tipo === 'prato-principal' ? 'Prato Principal' : 'Sobremesa'}
                        </span>
                        <div class="d-flex gap-2">
                            <button class="btn btn-outline-primary btn-sm" onclick="prepararEdicao(${receita.id})">
                                <i class="fas fa-edit"></i> Editar
                            </button>
                            <button class="btn btn-outline-danger btn-sm" onclick="excluirReceitaConfirmada(${receita.id})">
                                <i class="fas fa-trash"></i> Excluir
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `).join('');

    container.innerHTML = cardsHTML;
}


async function sincronizarComServidor() {
    try {
        const response = await fetch('http://localhost:3000/receitas');
        if (response.ok) {
            const receitasServidor = await response.json();
            
            const receitasLocal = JSON.parse(localStorage.getItem('receitas') || '[]');
            const receitasMescladas = [...receitasServidor];
          
            receitasLocal.forEach(receitaLocal => {
                if (!receitasServidor.find(r => r.id === receitaLocal.id)) {
                    receitasMescladas.push(receitaLocal);
                }
            });
            
            receitas = receitasMescladas;
            localStorage.setItem('receitas', JSON.stringify(receitas));
            exibirReceitas();
        } else {
            throw new Error('Erro ao sincronizar com o servidor');
        }
    } catch (error) {
        console.log('Erro ao sincronizar com o servidor:', error.message);
    }
}


function criarGraficoEstatisticas() {
    console.log('Atualizando gráfico de estatísticas...');
    
 
    const canvas = document.getElementById('graficoReceitas');
    if (!canvas) {
        console.log('Canvas do gráfico não encontrado');
        return;
    }

    
    if (typeof Chart === 'undefined') {
        console.error('Chart.js não carregado!');
        return;
    }

    
    const stats = calcularEstatisticas(receitas);
    console.log('Estatísticas calculadas:', stats);

   
    if (graficoReceitas) {
        graficoReceitas.destroy();
    }

    const ctx = canvas.getContext('2d');
    graficoReceitas = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pratos Principais', 'Sobremesas'],
            datasets: [{
                label: 'Quantidade de Receitas',
                data: [stats.pratosPrincipais, stats.sobremesas],
                backgroundColor: [
                    '#0d6efd', 
                    '#ffc107' 
                ],
                borderColor: '#ffffff',
                borderWidth: 3,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: `Total de Receitas: ${stats.total}`,
                    font: {
                        size: 18,
                        weight: 'bold'
                    },
                    padding: {
                        top: 10,
                        bottom: 20
                    }
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14
                        },
                        generateLabels: function(chart) {
                            const data = chart.data;
                            if (data.labels.length && data.datasets.length) {
                                return data.labels.map((label, i) => {
                                    const dataset = data.datasets[0];
                                    const value = dataset.data[i];
                                    const total = dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                                    
                                    return {
                                        text: `${label}: ${value} (${percentage}%)`,
                                        fillStyle: dataset.backgroundColor[i],
                                        strokeStyle: dataset.borderColor[i],
                                        lineWidth: dataset.borderWidth,
                                        hidden: false,
                                        index: i
                                    };
                                });
                            }
                            return [];
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((context.parsed / total) * 100) : 0;
                            return `${context.label}: ${context.parsed} receitas (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                animateScale: true,
                duration: 1500
            }
        }
    });


    atualizarEstatisticasDetalhadas(stats);
}


function calcularEstatisticas(receitas) {
    const stats = {
        total: receitas.length,
        pratosPrincipais: 0,
        sobremesas: 0,
        ingredientesMaisUsados: {},
        receitaMaisIngredientes: null,
        receitaMenosIngredientes: null,
        mediaIngredientes: 0
    };

    if (receitas.length === 0) return stats;

    let totalIngredientes = 0;
    let maxIngredientes = 0;
    let minIngredientes = Infinity;

    receitas.forEach(receita => {
       
        if (receita.tipo === 'prato-principal') {
            stats.pratosPrincipais++;
        } else if (receita.tipo === 'sobremesa') {
            stats.sobremesas++;
        }
 
        const ingredientes = receita.ingredientes.split(',').map(ing => ing.trim()).filter(ing => ing);
        const numIngredientes = ingredientes.length;
        totalIngredientes += numIngredientes;

        if (numIngredientes > maxIngredientes) {
            maxIngredientes = numIngredientes;
            stats.receitaMaisIngredientes = {
                nome: receita.nome,
                quantidade: numIngredientes
            };
        }

        
        if (numIngredientes < minIngredientes) {
            minIngredientes = numIngredientes;
            stats.receitaMenosIngredientes = {
                nome: receita.nome,
                quantidade: numIngredientes
            };
        }

 
        ingredientes.forEach(ingrediente => {
            const ing = ingrediente.toLowerCase();
            if (ing) {
                stats.ingredientesMaisUsados[ing] = (stats.ingredientesMaisUsados[ing] || 0) + 1;
            }
        });
    });

    stats.mediaIngredientes = receitas.length > 0 ? Math.round(totalIngredientes / receitas.length * 10) / 10 : 0;

    return stats;
}


function atualizarEstatisticasDetalhadas(stats) {
   
    let container = document.getElementById('estatisticas-detalhadas');
    if (!container) {
        const graficoContainer = document.querySelector('#graficoReceitas').closest('.row');
        container = document.createElement('div');
        container.id = 'estatisticas-detalhadas';
        container.className = 'row justify-content-center mt-4';
        graficoContainer.parentNode.insertBefore(container, graficoContainer.nextSibling);
    }

    
    const ingredientesOrdenados = Object.entries(stats.ingredientesMaisUsados)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5);

    container.innerHTML = `
        <div class="col-md-10">
            <div class="card p-4">
                <h5 class="mb-4 text-center"><i class="fas fa-chart-bar"></i> Resumo das Receitas</h5>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <h6><i class="fas fa-utensils"></i> Total de Pratos Principais</h6>
                        <div class="card text-white bg-primary shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">${stats.pratosPrincipais}</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <h6><i class="fas fa-birthday-cake"></i> Total de Sobremesas</h6>
                        <div class="card text-white bg-warning shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">${stats.sobremesas}</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <h6><i class="fas fa-chart-pie"></i> Receita com Mais Ingredientes</h6>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">${stats.receitaMaisIngredientes ? stats.receitaMaisIngredientes.nome : 'N/A'}</h5>
                            <p class="card-text">${stats.receitaMaisIngredientes ? stats.receitaMaisIngredientes.quantidade + ' ingredientes' : ''}</p>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <h6><i class="fas fa-chart-line"></i> Receita com Menos Ingredientes</h6>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">${stats.receitaMenosIngredientes ? stats.receitaMenosIngredientes.nome : 'N/A'}</h5>
                            <p class="card-text">${stats.receitaMenosIngredientes ? stats.receitaMenosIngredientes.quantidade + ' ingredientes' : ''}</p>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <h6><i class="fas fa-spaghetti"></i> Ingredientes Mais Usados</h6>
                    <ul class="list-group">
                        ${ingredientesOrdenados.map(([ingrediente, quantidade]) => `
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                ${ingrediente.charAt(0).toUpperCase() + ingrediente.slice(1)} 
                                <span class="badge bg-secondary rounded-pill">${quantidade}</span>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            </div>
        </div>
    `;
}


function editarReceita(id) {
    const receita = receitas.find(r => r.id === id);
    if (!receita) {
        mostrarMensagem('Receita não encontrada!', 'danger');
        return;
    }

  
    document.getElementById('nome').value = receita.nome;
    document.getElementById('imagem').value = receita.imagem;
    document.getElementById('ingredientes').value = receita.ingredientes;
    document.getElementById('preparo').value = receita.preparo;
    document.getElementById('tipo').value = receita.tipo;

 
    const modalTitle = document.getElementById('modalReceitaLabel');
    if (modalTitle) {
        modalTitle.textContent = 'Editar Receita';
    }

    const modal = new bootstrap.Modal(document.getElementById('modal-receita'));
    modal.show();

    window.receitaIdEdicao = id;
}

async function excluirReceita(id) {
    const receita = receitas.find(r => r.id === id);
    if (!receita) {
        mostrarMensagem('Receita não encontrada!', 'danger');
        return;
    }

    if (!confirm(`Tem certeza que deseja excluir a receita "${receita.nome}"?`)) {
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/receitas/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            receitas = receitas.filter(r => r.id !== id);
            console.log('Receita excluída do servidor:', id);
        } else {
            throw new Error('Erro ao excluir no servidor');
        }
    } catch (error) {
        console.log('Excluindo localmente:', error.message);
        receitas = receitas.filter(r => r.id !== id);
    }

    mostrarMensagem('Receita excluída com sucesso!', 'success');
    exibirReceitas();
    criarGraficoEstatisticas(); 

    
    localStorage.setItem('receitas', JSON.stringify(receitas));
}

window.addEventListener('load', () => {
    const receitasStorage = localStorage.getItem('receitas');
    if (receitasStorage) {
        receitas = JSON.parse(receitasStorage);
        console.log('Receitas carregadas do localStorage:', receitas);
        exibirReceitas();
        criarGraficoEstatisticas();
    }
});


document.getElementById('btn-limpar-receitas').addEventListener('click', () => {
    if (confirm('Tem certeza que deseja limpar todas as receitas?')) {
        receitas = [];
        localStorage.removeItem('receitas');
        exibirReceitas();
        criarGraficoEstatisticas();
        mostrarMensagem('Todas as receitas foram removidas.', 'success');
    }
});


document.getElementById('input-busca').addEventListener('input', function() {
    const termo = this.value.trim().toLowerCase();
    const receitasFiltradas = receitas.filter(receita =>
        receita.nome.toLowerCase().includes(termo) ||
        receita.preparo.toLowerCase().includes(termo)
    );
    exibirReceitas(receitasFiltradas);
});

document.getElementById('select-ordenar').addEventListener('change', function() {
    const criterio = this.value;
    let receitasOrdenadas = [...receitas];

    if (criterio === 'nome') {
        receitasOrdenadas.sort((a, b) => a.nome.localeCompare(b.nome));
    } else if (criterio === 'tipo') {
        receitasOrdenadas.sort((a, b) => a.tipo.localeCompare(b.tipo));
    } else if (criterio === 'ingredientes') {
        receitasOrdenadas.sort((a, b) => {
            const numIngredientesA = a.ingredientes.split(',').length;
            const numIngredientesB = b.ingredientes.split(',').length;
            return numIngredientesA - numIngredientesB;
        });
    }

    exibirReceitas(receitasOrdenadas);
});


document.getElementById('btn-exportar').addEventListener('click', function() {
    const tipoExportacao = document.getElementById('select-exportar').value;
    if (tipoExportacao === 'json') {
        exportarParaJSON(receitas);
    } else if (tipoExportacao === 'csv') {
        exportarParaCSV(receitas);
    } else {
        mostrarMensagem('Formato de exportação inválido!', 'danger');
    }
});

 
document.getElementById('btn-importar').addEventListener('click', function() {
    const arquivoInput = document.getElementById('arquivo-importar');
    const arquivo = arquivoInput.files[0];

    if (!arquivo) {
        mostrarMensagem('Selecione um arquivo para importar!', 'danger');
        return;
    }

    const leitor = new FileReader();
    leitor.onload = async function(e) {
        const conteudo = e.target.result;
        const tipoArquivo = arquivo.name.split('.').pop().toLowerCase();

        try {
            if (tipoArquivo === 'json') {
                await importarDeJSON(conteudo);
            } else if (tipoArquivo === 'csv') {
                await importarDeCSV(conteudo);
            } else {
                throw new Error('Formato de arquivo não suportado');
            }

            mostrarMensagem('Receitas importadas com sucesso!', 'success');
        } catch (error) {
            mostrarMensagem('Erro ao importar receitas: ' + error.message, 'danger');
        }
    };

    leitor.readAsText(arquivo);
});

// Função para exportar receitas para JSON
function exportarParaJSON(receitas) {
    const json = JSON.stringify(receitas, null, 2);
    const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'receitas.json';
    a.click();
    URL.revokeObjectURL(url);
}

function exportarParaCSV(receitas) {
    const cabecalhos = 'Nome,Imagem,Ingredientes,Preparo,Tipo\n';
    const linhas = receitas.map(receita => {
        const ingredientes = receita.ingredientes.split(',').map(ing => ing.trim()).join(';');
        return `"${receita.nome}","${receita.imagem}","${ingredientes}","${receita.preparo}","${receita.tipo}"`;
    });
    const csv = cabecalhos + linhas.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'receitas.csv';
    a.click();
    URL.revokeObjectURL(url);
}


async function importarDeJSON(conteudo) {
    const receitasNovas = JSON.parse(conteudo);
    receitas = receitas.concat(receitasNovas);
    exibirReceitas();
    criarGraficoEstatisticas();

    
    localStorage.setItem('receitas', JSON.stringify(receitas));
}

async function importarDeCSV(conteudo) {
    const linhas = conteudo.split('\n').slice(1);
    const receitasNovas = linhas.map(linha => {
        const [nome, imagem, ingredientes, preparo, tipo] = linha.split(',');
        return {
            id: Date.now(), 
            nome: nome.trim(),
            imagem: imagem.trim() || 'https://via.placeholder.com/300x200/cccccc/666666?text=Sem+Imagem',
            ingredientes: ingredientes.trim(),
            preparo: preparo.trim(),
            tipo: tipo.trim()
        };
    });

    receitas = receitas.concat(receitasNovas);
    exibirReceitas();
    criarGraficoEstatisticas();

    localStorage.setItem('receitas', JSON.stringify(receitas));
}


function atualizarMenu() {
    const usuario = JSON.parse(sessionStorage.getItem('usuarioLogado'));
    document.getElementById('menu-favoritos').style.display = usuario ? 'block' : 'none';
    document.getElementById('menu-cadastro').style.display = usuario && usuario.admin ? 'block' : 'none';
    document.getElementById('btn-login').style.display = usuario ? 'none' : 'block';
    document.getElementById('btn-logout').style.display = usuario ? 'block' : 'none';
}