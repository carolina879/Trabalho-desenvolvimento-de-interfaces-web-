
document.addEventListener('DOMContentLoaded', function() {
    carregarReceitasPorTipo('prato-principal', 'receitas-prato-principal');
});